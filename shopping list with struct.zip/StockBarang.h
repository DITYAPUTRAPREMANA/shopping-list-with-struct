#include <stdio.h>

int StockBarang() {
  printf("+----------------------------------------------------+\n");
  printf("|                     Stok Barang                    |\n");
  printf("|------+-------------+-------------+-----------------|\n");
  printf("| Kode | Nama Barang |    Harga    |      Bahan      |\n");
  printf("+------+-------------+-------------+-----------------+\n");

  char namaFile[225];
  FILE *fp;
  char ch;
  fp = fopen("DaftarBarang.txt", "r");
    if (fp == NULL) {
        printf("File DaftarBarang.txt tidak ditemukan. Membuat file baru.\n");
        return 1;
    }

    while ((ch = fgetc(fp)) != EOF) {
    printf("%c", ch);
  }
  fclose(fp);


   return(0);
}
