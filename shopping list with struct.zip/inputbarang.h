#include <stdio.h>
#include <stdlib.h>
#include "struct.h"

void inputBarang(){

    printf("+------------------------------------+\n");
    printf("|          Input Barang anda         |\n");
    printf("+------------------------------------+\n");

    int n;
    printf("masukan jumlah barang : ");
    scanf("%d", &n);
    struct Persediaan Barang[n];
    for (int i=0; i<n; i++)
    {
        printf("\n\nData Barang ke-%d:", i + 1);
        printf ("\n");
        printf("kode barang        :  [%d]  :", i+1);
        scanf ("%d", &Barang[i].details.kode);
        printf("nama barang        :  [%d]  :", i+1);
        scanf ("%s", Barang[i].details.nama);
        printf("bahan barang       :  [%d]  :", i+1);
        scanf ("%s", Barang[i].details.bahan);
        printf("harga barang       :  [%d]  : Rp. ", i+1);
        scanf ("%d", &Barang[i].harga);
        printf("jumlah barang      :  [%d]  :", i+1);
        scanf ("%d", &Barang[i].jumlah);
        printf("\n");

    }
for (int i=0; i<n ;i++){
        printf("\n\nData Barang ke-%d:", i + 1);
        printf("\nKode Barang: %d", Barang[i].details.kode);
        printf("\nNama Barang: %s", Barang[i].details.nama);
        printf("\nBahan Dasar: %s", Barang[i].details.bahan);
        printf("\nHarga Barang: Rp. %d", Barang[i].harga);
        printf("\nJumlah Barang: %d", Barang[i].jumlah);
    }

}