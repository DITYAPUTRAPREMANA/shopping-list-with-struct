#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "inputbarang.h"
#include "StockBarang.h"

void main() 
{
    system ("cls");
    int pilihan;
    do {

        printf("\n+------------------------------------+\n");
        printf("|   Tugas Database toko mabel ramos  |\n");
        printf("+------------------------------------+\n");
        printf("| 1. lihat stok barang               |\n");
        printf("| 2. Input Barang                    |\n");
        printf("| 3. Exit                            |\n");
        printf("+------------------------------------+\n");
        printf("\n");
        printf("   Dibuat Oleh Aditya Premana Putra  \n");
        printf("\n");
        time_t waktu_saat_ini = time(NULL);
        struct tm* waktu_lokal = localtime(&waktu_saat_ini);
        printf("%02d/%02d/%d\t\t\t %02d:%02d\t\n",
           waktu_lokal->tm_mday, waktu_lokal->tm_mon + 1, waktu_lokal->tm_year + 1900,
           waktu_lokal->tm_hour, waktu_lokal->tm_min);

        printf("\n");
        printf(" Pilih [1, 2, 3] : ");
        scanf("%d", &pilihan);

    switch (pilihan){
    case 1:
        system("cls");
        StockBarang();
        break;
    case 2:
        system("cls");
        inputBarang();
        break;
    case 3:
        system("cls");
            printf("+-------------------------------------+\n");
            printf("|        Terima kasih telah           |\n");
            printf("|      menggunakan aplikasi ini       |\n");
            printf("+-------------------------------------+\n");
            printf("|        Nama : Aditya Premana Putra  |\n");
            printf("|        NIM  : 2308561005            |\n");
            printf("|        Kelas: E / Informatika       |\n");
            printf("+-------------------------------------+\n");
            system("pause");;
        break;
    default:
        system("cls");
        printf("pilihan invalid");
        break;
    }

  } while ( pilihan !=3);

}